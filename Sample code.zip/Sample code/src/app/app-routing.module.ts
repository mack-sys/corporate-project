import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { BookingComponent } from './booking/booking.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { LoginComponent } from './login/login.component';
import { PickupDropComponent } from './pickup-drop/pickup-drop.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [ 
  { path: 'pickup-drop', component: PickupDropComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'login', component:LoginComponent  },
  { path: 'booking', component: BookingComponent },
  { path: 'about', component: AboutComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'feedback', component: FeedbackComponent }
  ];
  

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
